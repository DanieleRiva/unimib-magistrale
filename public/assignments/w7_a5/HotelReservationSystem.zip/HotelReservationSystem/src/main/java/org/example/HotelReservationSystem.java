package org.example;

import java.util.ArrayList;
import java.util.List;

public class HotelReservationSystem {

    public static void main(String[] args) {
        Reservation reservation = new Reservation();

        // Add rooms to the reservation
        reservation.addRoom(new Room("Double Room", 200.00));
        reservation.addRoom(new Room("Single Room", 150.00));
        reservation.addRoom(new Room("Suite", 400.00));

        // Apply discount based on customer status and rooms
        boolean isVIP = true;
        reservation.applyDiscount(isVIP);

        // Process payment
        double paymentAmount = 600.00;
        reservation.processPayment(paymentAmount);

        // Check if the reservation can be canceled
        boolean canCancel = reservation.canCancelReservation();

        // Check if breakfast is included in the reservation
        boolean breakfastIncluded = reservation.isBreakfastIncluded();
    }
}